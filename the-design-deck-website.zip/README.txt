THE DESIGN DECK BY SHANMUKH

Ready-to-upload website.
Open index.html to preview it. Replace the placeholder phone/WhatsApp number (919999999999) before publishing.
